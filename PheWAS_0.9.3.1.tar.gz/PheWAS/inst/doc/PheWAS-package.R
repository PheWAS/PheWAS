### R code from vignette source 'PheWAS-package.Rnw'

###################################################
### code chunk number 1: example
###################################################
library(PheWAS)
example(PheWAS)


###################################################
### code chunk number 2: plot
###################################################
phewasManhattan(results, annotate.angle=0)


###################################################
### code chunk number 3: fig1
###################################################
phewasManhattan(results, annotate.angle=0)


